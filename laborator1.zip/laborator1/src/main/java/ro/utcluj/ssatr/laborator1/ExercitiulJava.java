/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ro.utcluj.ssatr.laborator1;

/**
 *
 * @author natalia
 */
public class ExercitiulJava {
    public static void main(String[] args) {
        System.out.println("Primul laborator");
    }
}
